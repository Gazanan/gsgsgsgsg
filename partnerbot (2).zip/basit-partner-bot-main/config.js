module.exports = {
    token: "", 
    prefix: ""
}

